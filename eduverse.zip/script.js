function enter(level){

document.getElementById("panel").innerHTML = `
<h2>Welcome to ${level} Galaxy</h2>

<p>Select Board:</p>

<button onclick="board('CBSE')">CBSE</button>
<button onclick="board('ICSE')">ICSE</button>
<button onclick="board('STATE')">STATE</button>

<br><br>

<p>Subjects:</p>
<button>Math</button>
<button>Science</button>
<button>English</button>
<button>Social</button>

<br><br>
🔥 AI Tutor Coming Soon  
🎮 Games Coming Soon  
🎬 Videos Coming Soon
`;

}

function board(b){
alert("Board Selected: "+b);
}
